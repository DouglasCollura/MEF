document.addEventListener('DOMContentLoaded', function(){

    M.AutoInit();
});
